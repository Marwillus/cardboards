import React, { useState } from "react";

import "./layout/App.scss";
import logo from "./images/Logo.png";
import Board from "./components/Board";
import Input from "./components/Input";

const fakeData = {
  like: [
    {
      id: "like-0",
      value: "Yannick ist wieder öfter bei daily/checkout dabei!!",
      likes: 3,
      liked: false,
    },
    {
      id: "like-1",
      value:
        "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur sunt in quis nisi ipsam corrupti?",
      likes: 1,
      liked: false,
    },
    {
      id: "like-2",
      value:
        "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora sed, ea neque soluta recusandae similique id illo dolor voluptate. Animi vel a repellendus voluptatem at, eveniet fugit commodi praesentium enim?",
      likes: 5,
      liked: false,
    },
  ],
  wish: [
    {
      id: "wish-0",
      value: "Wuenschte ich haette weniger aussetzer",
      likes: 3,
      liked: false,
    },
  ],
  issue: [
    {
      id: "issue-0",
      value: "Yannick ist wieder öfter bei daily/checkout dabei!!",
      likes: 3,
      liked: false,
    },
    {
      id: "issue-1",
      value: "Die Mietpreisbremse war doch ganz ok",
      likes: 1,
      liked: false,
    },
  ],
};

function App() {
  const [listItems, setListItems] = useState(fakeData);
  const [itemText, setItemText] = useState("");
  const [itemCategory, setItemCategory] = useState("");

  const getWeek = () => {
    var date = new Date();
    var week1 = new Date(date.getFullYear(), 0, 4);
    return (
      1 +
      Math.round(
        ((date.getTime() - week1.getTime()) / 86400000 -
          3 +
          ((week1.getDay() + 6) % 7)) /
          7
      )
    );
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const updateList = { ...listItems };
    updateList[itemCategory].push({
      id: `${itemCategory}-${listItems[itemCategory].length}`,
      value: itemText,
      likes: 0,
    });
    setListItems(updateList);
    setItemText("");
  };

  const handleLike = (id) => {
    const updateLikes = { ...listItems };
    const category = id.split("-")[0];
    updateLikes[category].forEach((element) => {
      if (element.id === id) {
        if (!element.liked) {
          element.likes++;
          element.liked = true;
        } else {
          element.likes--;
          element.liked = false;
        }
      }
    });
    setListItems(updateLikes);
  };

  return (
    <div className="App">
      <header>
        <div className="container title">
          <img src={logo} alt="logo" className="logo" />
          <h3>LIKES / WISHES / ISSUES</h3>
        </div>
      </header>
      <main className="container">
        <h1 className="week">KW {getWeek()}</h1>
        <section className="board-section">
          <Board title="LIKES" data={listItems.like} handleLike={handleLike} />
          <Board title="WISHES" data={listItems.wish} handleLike={handleLike} />
          <Board
            title="ISSUES"
            data={listItems.issue}
            handleLike={handleLike}
          />
        </section>
        <Input
          setItemCategory={setItemCategory}
          itemText={itemText}
          setItemText={setItemText}
          onSubmit={onSubmit}
        />
      </main>
    </div>
  );
}

export default App;
