import Item from "./Item";

function Board({ title, data, handleLike }) {
  // console.log(data);
  return (
    <div className="card board">
      <h3 className="board-title">{title}</h3>
      {data.map((d) => {
        return (
          <Item
            key={d.id}
            id={d.id}
            text={d.value}
            likes={d.likes}
            liked={d.liked}
            handleLike={handleLike}
          />
        );
      })}
    </div>
  );
}

export default Board;
